
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectNttApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyectNttApplication.class, args);
	}

}
